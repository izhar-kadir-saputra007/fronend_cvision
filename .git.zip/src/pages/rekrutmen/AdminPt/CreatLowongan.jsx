const CreatLowongan = () => {
  return (
    <div>CreatLowongan</div>
  )
}

export default CreatLowongan