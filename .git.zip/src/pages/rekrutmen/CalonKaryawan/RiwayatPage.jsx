import Navbar from "../../../components/Navbar"
import RiwayatPsikotest from "../../../components/rekrutmen/CalonKaryawan/profilUser/RiwayatPsikotest"
const Riwayat = () => {
  return (
    <>
    <Navbar />
    <div className="container mx-auto p-5 pt-40">
    <RiwayatPsikotest/ >
    </div>
    </>
  )
}

export default Riwayat