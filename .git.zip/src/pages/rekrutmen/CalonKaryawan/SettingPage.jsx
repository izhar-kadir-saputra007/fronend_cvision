import Navbar from '../../../components/Navbar'
import ChangePasswordForm from '../../../components/rekrutmen/CalonKaryawan/profilUser/ChangePasswordForm'
const SettingPage = () => {
  return (
    <>
    <Navbar />
<div className='container mx-auto pt-28'>
<ChangePasswordForm />
<div>
  
</div>
</div>
    </>
  )
}

export default SettingPage