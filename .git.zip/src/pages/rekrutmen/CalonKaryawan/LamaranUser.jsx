import Navbar from "../../../components/Navbar"
import LamaranList from "../../../components/rekrutmen/CalonKaryawan/profilUser/LamaranList";
const LamaranUser = () => {
  return (
    <>
    <Navbar />
    <div className="container mx-auto p-5 pt-40">
    <LamaranList/>
    </div>
    </>
  )
}

export default LamaranUser